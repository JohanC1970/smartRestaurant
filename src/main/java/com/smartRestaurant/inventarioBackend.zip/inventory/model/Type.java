package com.smartRestaurant.inventory.model;

public enum Type {
    ENTRY, EXIT
}
