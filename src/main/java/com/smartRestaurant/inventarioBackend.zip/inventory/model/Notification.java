package com.smartRestaurant.inventory.model;

public class Notification {

    private String id;
    private String
}
