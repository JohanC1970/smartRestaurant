package com.smartRestaurant.inventory.model;

public enum State {
    ACTIVE, INACTIVE
}
