package com.smartRestaurant.inventory.dto.Product;

public record StockMovementDTO(double weight) {
}
