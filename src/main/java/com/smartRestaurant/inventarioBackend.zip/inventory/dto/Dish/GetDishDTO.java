package com.smartRestaurant.inventory.dto.Dish;

public record GetDishDTO() {
}
