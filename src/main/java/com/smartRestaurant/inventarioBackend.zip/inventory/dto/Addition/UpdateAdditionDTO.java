package com.smartRestaurant.inventory.dto.Addition;

public record UpdateAdditionDTO() {
}
