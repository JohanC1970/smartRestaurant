package com.smartRestaurant.inventory.dto.Addition;

public record GetAdditionDTO() {
}
