package com.smartRestaurant.inventory.dto;

public record ValidationDTO(String field, String defaultMessage) {
}
