package com.smartRestaurant.inventory.dto.Product;

public record GetProductDTO() {
}
