package com.smartRestaurant.inventory.dto.Addition;

public record CreateAdditionDTO(String name) {
}
