package com.smartRestaurant.inventory.dto.drink;

public record UpdateDrinkDTO() {
}
