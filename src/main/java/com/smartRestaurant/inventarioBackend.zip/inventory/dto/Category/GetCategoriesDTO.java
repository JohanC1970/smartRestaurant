package com.smartRestaurant.inventory.dto.Category;

public record GetCategoriesDTO() {
}
