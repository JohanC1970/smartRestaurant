package com.smartRestaurant.inventory.dto.Notification;

import java.time.LocalDateTime;

public class Notification {

    private String id;
    private LocalDateTime date;
    private String tye;
    private String description;

}
